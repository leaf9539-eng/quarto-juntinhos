// Player do YouTube (IFrame API oficial) dentro do monitor, sincronizado pelo servidor.
// O servidor guarda {id, playing, pos, at}; cada cliente calcula a posição esperada com o relógio do servidor.
const ID = /^[\w-]{11}$/;
const ERR = {
  2: 'Link ou ID de vídeo inválido.', 5: 'Erro no player HTML5. Tente de novo.', 100: 'Vídeo não encontrado ou privado.',
  101: 'O dono deste vídeo não permite reprodução incorporada.', 150: 'O dono deste vídeo não permite reprodução incorporada.',
  153: 'O YouTube recusou o player (verifique o endereço do site).',
};
const fmt = s => { s = Math.max(0, Math.floor(s || 0)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const ytReady = () => new Promise(res => {
  if (window.YT && YT.Player) return res();
  const prev = window.onYouTubeIframeAPIReady;
  window.onYouTubeIframeAPIReady = () => { prev && prev(); res(); };
  const s = document.createElement('script'); s.src = 'https://www.youtube.com/iframe_api'; document.head.appendChild(s);
});

export function parseVideoId(text) {
  const t = String(text || '').trim(); if (ID.test(t)) return t;
  try {
    const u = new URL(/^https?:\/\//i.test(t) ? t : 'https://' + t), h = u.hostname.replace(/^(www|m|music)\./, '');
    if (h === 'youtu.be') { const v = u.pathname.split('/')[1]; return ID.test(v || '') ? v : null; }
    if (h === 'youtube.com' || h === 'youtube-nocookie.com') {
      const v = u.searchParams.get('v'); if (ID.test(v || '')) return v;
      const m = u.pathname.match(/^\/(?:embed|shorts|live|v)\/([\w-]{11})/); if (m) return m[1];
    }
  } catch { /* link inválido */ }
  return null;
}

export class VideoPlayer {
  constructor(root, net, toast) {
    Object.assign(this, { root, net, toast, state: null, cur: null, userVol: 60, prox: 1, powered: false, ready: false, tickN: 0, blocked: false, dragging: false });
    const q = s => root.querySelector(s); this.q = q;
    this.url = q('#url'); this.msg = q('#msg'); this.pp = q('#pp'); this.seek = q('#seek'); this.time = q('#time');
    q('#load').onclick = () => this.load();
    this.url.addEventListener('keydown', e => { if (e.key === 'Enter') this.load(); });
    this.pp.onclick = () => this.toggle();
    q('#shield').onclick = () => { if (this.blocked) { this.blocked = false; this.p.playVideo(); this.hide(); } else this.toggle(); };
    this.seek.oninput = () => (this.dragging = true);
    this.seek.onchange = () => { this.dragging = false; const d = this.p?.getDuration?.() || 0; if (d && this.state?.id) net.emit('v:seek', this.seek.value / 1000 * d); };
    q('#vol').oninput = e => { this.userVol = +e.target.value; this.applyVol(); };
    q('#fs').onclick = () => { if (document.fullscreenElement) document.exitFullscreen(); else (root.requestFullscreen || root.webkitRequestFullscreen)?.call(root); };
    q('#poweroff').onclick = () => net.emit('pc', false);
  }
  async init() {
    await ytReady();
    this.p = new YT.Player(this.q('#yt'), {
      width: '100%', height: '100%',
      playerVars: { controls: 0, disablekb: 1, rel: 0, modestbranding: 1, playsinline: 1, fs: 0, iv_load_policy: 3, origin: location.origin },
      events: { onReady: () => { this.ready = true; this.applyVol(); this.apply(this.state); }, onStateChange: e => this.onState(e), onError: e => this.onError(e.data) },
    });
    setInterval(() => this.tick(), 500);
  }
  show(text, err) { this.msg.textContent = text; this.msg.className = err ? 'err' : ''; this.msg.dataset.k = ''; }
  hide() { this.msg.className = 'hide'; }
  load() {
    const id = parseVideoId(this.url.value);
    if (!id) return this.show('Link inválido. Use algo como https://www.youtube.com/watch?v=XXXXXXXXXXX', true);
    this.net.emit('v:load', id);
  }
  toggle() { if (this.state?.id) this.net.emit(this.state.playing ? 'v:pause' : 'v:play'); }
  expected() { const s = this.state; return s.playing ? s.pos + (this.net.now() - s.at) / 1000 : s.pos; }
  // aplica o estado compartilhado {id, playing, pos, at} vindo do servidor
  apply(s) {
    this.state = s || null; if (!this.ready) return;
    const p = this.p;
    if (!s || !s.id) { this.cur = null; p.stopVideo(); this.show('Cole um link do YouTube e clique em CARREGAR VÍDEO'); return this.ui(); }
    const want = Math.max(0, this.expected());
    if (s.id !== this.cur) {
      this.cur = s.id; this.hide(); this.blocked = false;
      if (s.playing && this.powered) { p.loadVideoById({ videoId: s.id, startSeconds: want }); this.watchAutoplay(); }
      else p.cueVideoById({ videoId: s.id, startSeconds: want });
    } else if (this.powered) {
      if (Math.abs((p.getCurrentTime?.() || 0) - want) > 1.2) p.seekTo(want, true);
      if (s.playing) { p.playVideo(); this.watchAutoplay(); } else p.pauseVideo();
    }
    this.ui();
  }
  setPower(on) {
    this.powered = on; if (!this.ready) return;
    if (!on) this.p.pauseVideo(); else if (this.state) this.apply(this.state);
  }
  watchAutoplay() { // alguns navegadores exigem um toque para iniciar o vídeo
    clearTimeout(this.wt);
    this.wt = setTimeout(() => {
      const s = this.p.getPlayerState?.();
      if (this.state?.playing && this.powered && s !== 1 && s !== 3) { this.blocked = true; this.show('Toque na tela para iniciar a reprodução'); }
    }, 3500);
  }
  onState(e) {
    const S = YT.PlayerState;
    if (e.data === S.PLAYING || e.data === S.BUFFERING) { if (this.blocked) { this.blocked = false; this.hide(); } }
    if (e.data === S.PLAYING && this.state && !this.state.playing) this.p.pauseVideo(); // estado compartilhado = pausado
  }
  onError(code) { this.cur = null; const m = ERR[code] || `Não foi possível reproduzir este vídeo (erro ${code}).`; this.show(m, true); this.toast(m); }
  ui() { this.pp.textContent = this.state?.playing ? '⏸' : '▶'; }
  applyVol() { this.p?.setVolume?.(Math.round(this.userVol * this.prox)); }
  setProximity(f) { this.prox = f; this.applyVol(); } // quanto mais longe da tela, mais baixo
  tick() {
    const p = this.p; if (!this.ready || !p.getCurrentTime) return;
    const dur = p.getDuration?.() || 0, t = p.getCurrentTime() || 0;
    if (!this.dragging && dur) this.seek.value = Math.round(t / dur * 1000);
    this.time.textContent = `${fmt(t)} / ${fmt(dur)}`;
    this.tickN = (this.tickN + 1) % 6; // a cada 3 s corrige a deriva em relação ao servidor
    if (this.tickN === 0 && this.state?.playing && this.powered && p.getPlayerState() === 1) {
      const want = this.expected(); if (Math.abs(t - want) > 1) p.seekTo(want, true);
    }
  }
}
