// Sons gerados com WebAudio (sem arquivos): passos, interruptor, computador, ambiente discreto.
export class Sfx {
  constructor() { this.ctx = null; this.vol = .6; }
  init() {
    if (this.ctx) { this.ctx.resume?.(); return; }
    const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
    const c = this.ctx = new C(), n = c.sampleRate, b = c.createBuffer(1, n * 2, n), d = b.getChannelData(0);
    let l = 0; for (let i = 0; i < d.length; i++) { l = (l + .02 * (Math.random() * 2 - 1)) / 1.02; d[i] = l * 3.5; } // ruído marrom
    this.noise = b;
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = b; s.loop = true; f.type = 'lowpass'; f.frequency.value = 260; g.gain.value = .05 * this.vol;
    s.connect(f).connect(g).connect(c.destination); s.start(); // som ambiente
  }
  tone(f, t = .12, type = 'sine', v = .15, f2 = null, delay = 0) {
    const c = this.ctx; if (!c) return;
    const o = c.createOscillator(), g = c.createGain(), s = c.currentTime + delay;
    o.type = type; o.frequency.setValueAtTime(f, s); if (f2) o.frequency.exponentialRampToValueAtTime(f2, s + t);
    g.gain.setValueAtTime(v * this.vol, s); g.gain.exponentialRampToValueAtTime(.0001, s + t);
    o.connect(g).connect(c.destination); o.start(s); o.stop(s + t + .02);
  }
  step() {
    const c = this.ctx; if (!c) return;
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain(), t = c.currentTime;
    s.buffer = this.noise; s.playbackRate.value = 1.2 + Math.random() * .4; f.type = 'lowpass'; f.frequency.value = 380 + Math.random() * 120;
    g.gain.setValueAtTime(.22 * this.vol, t); g.gain.exponentialRampToValueAtTime(.001, t + .09);
    s.connect(f).connect(g).connect(c.destination); s.start(t, Math.random()); s.stop(t + .1);
  }
  click() { this.tone(900, .04, 'square', .05); }
  switch() { this.tone(300, .03, 'square', .08); this.tone(180, .05, 'square', .06, null, .04); }
  pcOn() { this.tone(220, .5, 'sawtooth', .05, 880); this.tone(660, .15, 'sine', .08, null, .5); this.tone(990, .2, 'sine', .08, null, .65); }
  pcOff() { this.tone(660, .35, 'sine', .08, 110); }
}
