// Entrada: teclado/mouse, toque (joystick + olhar) e detecção automática de teclado físico.
// Navegadores não avisam "teclado conectado/desconectado": inferimos por eventos reais de teclado/mouse
// (keydown com code real, ignorando o teclado virtual keyCode 229) e voltamos ao toque quando o usuário toca na tela.
const $ = s => document.querySelector(s);
export class Input {
  constructor(canvas, hooks) {
    this.k = new Set(); this.joy = { x: 0, y: 0 }; this.look = { x: 0, y: 0 }; this.h = hooks;
    this.touchCapable = navigator.maxTouchPoints > 0 || 'ontouchstart' in window;
    this.hw = !matchMedia('(pointer:coarse)').matches; // PC começa com teclado+mouse; celular/tablet começa com toque
    this.hwAt = performance.now();
    this.apply();
    addEventListener('keydown', e => this.keyDown(e), true);
    addEventListener('keyup', e => this.k.delete(e.code), true);
    addEventListener('blur', () => this.k.clear());
    addEventListener('pointermove', e => { if (e.pointerType === 'mouse') this.seenHW(); }, { capture: true, passive: true });
    addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse') this.seenHW();
      else if (e.pointerType === 'touch' && this.hw && performance.now() - this.hwAt > 5000) { this.hw = false; this.apply(); } // teclado sumiu: volta o toque
    }, true);
    document.addEventListener('mousemove', e => { if (document.pointerLockElement) { this.look.x += e.movementX * .0022; this.look.y += e.movementY * .0022; } });
    this.drag($('#lookzone')); this.drag(canvas); this.joystick($('#joy'));
    $('#btnE').addEventListener('pointerdown', e => { e.preventDefault(); hooks.interact(); });
    $('#btnMenu').addEventListener('click', () => hooks.menu());
    $('#btnBack').addEventListener('click', () => hooks.esc());
  }
  seenHW() { this.hwAt = performance.now(); if (!this.hw) { this.hw = true; this.apply(); } }
  apply() {
    document.body.classList.toggle('touchui', this.touchCapable && !this.hw);
    if (this.hw) { this.joy.x = this.joy.y = 0; $('#joy i').style.transform = ''; }
  }
  keyDown(e) {
    if (e.isTrusted && e.keyCode !== 229 && e.key !== 'Unidentified' && e.code) this.seenHW();
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName);
    if (e.code === 'Escape') { if (typing) e.target.blur(); this.h.esc(); return; }
    if (typing || e.repeat) return;
    this.k.add(e.code);
    if (e.code === 'KeyE') this.h.interact();
    if (e.code === 'Space' || e.code.startsWith('Arrow')) e.preventDefault();
  }
  move() {
    const k = this.k, d = (a, b) => (k.has(a) || k.has(b) ? 1 : 0);
    let x = d('KeyD', 'ArrowRight') - d('KeyA', 'ArrowLeft') + this.joy.x, y = d('KeyW', 'ArrowUp') - d('KeyS', 'ArrowDown') + this.joy.y;
    const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
    return { x, y };
  }
  run() { return this.k.has('ShiftLeft') || this.k.has('ShiftRight'); }
  takeLook() { const l = { ...this.look }; this.look.x = this.look.y = 0; return l; }
  drag(el) { // arrastar o dedo = girar a câmera
    let id = null, lx = 0, ly = 0;
    el.addEventListener('pointerdown', e => { if (e.pointerType !== 'touch' || id !== null) return; id = e.pointerId; lx = e.clientX; ly = e.clientY; el.setPointerCapture(id); });
    el.addEventListener('pointermove', e => { if (e.pointerId !== id) return; this.look.x += (e.clientX - lx) * .0055; this.look.y += (e.clientY - ly) * .0055; lx = e.clientX; ly = e.clientY; });
    const up = e => { if (e.pointerId === id) id = null; };
    el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  }
  joystick(el) {
    const knob = el.firstElementChild; let id = null, cx = 0, cy = 0;
    const upd = e => {
      let dx = e.clientX - cx, dy = e.clientY - cy; const R = 48, l = Math.hypot(dx, dy);
      if (l > R) { dx *= R / l; dy *= R / l; }
      knob.style.transform = `translate(${dx}px,${dy}px)`; this.joy.x = dx / R; this.joy.y = -dy / R;
    };
    el.addEventListener('pointerdown', e => { id = e.pointerId; el.setPointerCapture(id); const r = el.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; upd(e); });
    el.addEventListener('pointermove', e => { if (e.pointerId === id) upd(e); });
    const end = e => { if (e.pointerId !== id) return; id = null; this.joy.x = this.joy.y = 0; knob.style.transform = ''; };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  }
}
