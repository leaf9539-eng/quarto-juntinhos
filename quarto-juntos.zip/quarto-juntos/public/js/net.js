// Rede: Socket.IO + sincronização do relógio com o servidor (usada para alinhar o vídeo).
export class Net {
  constructor() { this.s = io({ transports: ['websocket', 'polling'] }); this.off = 0; }
  on(ev, fn) { this.s.on(ev, fn); return this; }
  emit(ev, ...a) { this.s.emit(ev, ...a); }
  req(ev, ...a) {
    return new Promise((res, rej) => {
      const t = setTimeout(() => rej(new Error('timeout')), 8000);
      this.s.emit(ev, ...a, r => { clearTimeout(t); res(r); });
    });
  }
  now() { return Date.now() + this.off; } // "agora" na hora do servidor
  async sync(n = 6) { // várias medições; vale a de menor latência
    let best = null;
    for (let i = 0; i < n; i++) {
      const t0 = Date.now(), srv = await this.req('t'), t1 = Date.now(), rtt = t1 - t0;
      if (!best || rtt < best.rtt) best = { rtt, off: srv + rtt / 2 - t1 };
      await new Promise(r => setTimeout(r, 50));
    }
    this.off = best.off;
  }
}
