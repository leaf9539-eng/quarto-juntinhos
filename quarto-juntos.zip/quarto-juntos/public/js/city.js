// Cenário fora da janela: céu em degradê, estrelas, lua e uma cidade (prédios com janelas acesas) lá embaixo.
// O quarto fica num andar alto: o chão da cidade está bem abaixo, então a janela mostra telhados e o horizonte.
import * as THREE from 'three';
const rng = s => () => { s |= 0; s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
export function buildCity(scene, low) {
  const rnd = rng(20261105), G = -52, R = 900;
  // céu
  const sg = new THREE.SphereGeometry(R, 32, 16), pos = sg.attributes.position, col = new Float32Array(pos.count * 3);
  const top = new THREE.Color(0x050816), mid = new THREE.Color(0x1b2455), hor = new THREE.Color(0xff9a6a), bot = new THREE.Color(0x1a1230), c = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i) / R;
    if (y > .3) c.copy(mid).lerp(top, Math.min(1, (y - .3) / .6)); else if (y > 0) c.copy(hor).lerp(mid, y / .3); else c.copy(hor).lerp(bot, Math.min(1, -y * 5));
    col.set([c.r, c.g, c.b], i * 3);
  }
  sg.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const sky = new THREE.Mesh(sg, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false }));
  sky.renderOrder = -10; scene.add(sky);
  const st = []; for (let i = 0; i < 420; i++) { const y = .06 + rnd() * .94, r = Math.sqrt(1 - y * y), a = rnd() * 6.283; st.push(850 * r * Math.sin(a), 850 * y, -850 * r * Math.cos(a)); }
  const sgeo = new THREE.BufferGeometry(); sgeo.setAttribute('position', new THREE.Float32BufferAttribute(st, 3));
  scene.add(new THREE.Points(sgeo, new THREE.PointsMaterial({ size: 1.8, sizeAttenuation: false, color: 0xffffff, fog: false, transparent: true, opacity: .8, depthWrite: false })));
  const moon = new THREE.Mesh(new THREE.CircleGeometry(34, 32), new THREE.MeshBasicMaterial({ color: 0xfff1c9, fog: false }));
  moon.position.set(130, 150, -780); moon.lookAt(0, 0, 0); scene.add(moon);
  // textura de janelas (4x4 por bloco de 8 m)
  const cv = document.createElement('canvas'); cv.width = cv.height = 64; const g = cv.getContext('2d');
  g.fillStyle = '#0a0f22'; g.fillRect(0, 0, 64, 64); const lit = ['#ffd98a', '#ffe9b8', '#ffc46b', '#a9dcff'];
  for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) { g.fillStyle = rnd() < .42 ? lit[(rnd() * lit.length) | 0] : '#141b36'; g.fillRect(x * 16 + 3, y * 16 + 4, 10, 8); }
  const tex = new THREE.CanvasTexture(cv); tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = low ? 1 : 4;
  // prédios: uma única malha (1 draw call)
  const P = [], U = [], C = [], I = []; let vi = 0;
  const quad = (a, b, c2, d, u, v, k) => { P.push(...a, ...b, ...c2, ...d); U.push(0, 0, u, 0, u, v, 0, v); for (let i = 0; i < 4; i++) C.push(...k); I.push(vi, vi + 1, vi + 2, vi, vi + 2, vi + 3); vi += 4; };
  const N = low ? 220 : 380;
  for (let i = 0; i < N; i++) {
    let a = rnd() * 6.283; const a2 = a > Math.PI ? a - 6.283 : a; // a = 0 é o norte (-Z), onde fica a janela
    const d = (Math.abs(a2) < .6 ? 110 : 45) + Math.pow(rnd(), 1.5) * 560, x = Math.sin(a) * d, z = -Math.cos(a) * d;
    const w = 12 + rnd() * 26, dp = 12 + rnd() * 26, h = (22 + Math.pow(rnd(), 2.2) * 150) * (.55 + d / 650), y0 = G, y1 = G + h;
    const x0 = x - w / 2, x1 = x + w / 2, z0 = z - dp / 2, z1 = z + dp / 2, t = .65 + rnd() * .6, k = [t * (.9 + rnd() * .2), t, t * (1 + rnd() * .15)];
    quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], w / 8, h / 8, k);
    quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], w / 8, h / 8, k);
    quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], dp / 8, h / 8, k);
    quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], dp / 8, h / 8, k);
    quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], .04, .04, k);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); geo.setAttribute('uv', new THREE.Float32BufferAttribute(U, 2)); geo.setAttribute('color', new THREE.Float32BufferAttribute(C, 3)); geo.setIndex(I);
  const city = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, vertexColors: true })); city.frustumCulled = false; scene.add(city);
  // chão com ruas
  const rc = document.createElement('canvas'); rc.width = rc.height = 128; const r = rc.getContext('2d');
  r.fillStyle = '#0b0e1d'; r.fillRect(0, 0, 128, 128); r.fillStyle = '#171b33'; r.fillRect(0, 56, 128, 16); r.fillRect(56, 0, 16, 128);
  r.fillStyle = '#c9a25a'; for (let i = 0; i < 8; i++) { r.fillRect(i * 16 + 4, 63, 8, 2); r.fillRect(63, i * 16 + 4, 2, 8); }
  const rt = new THREE.CanvasTexture(rc); rt.wrapS = rt.wrapT = THREE.RepeatWrapping; rt.repeat.set(20, 20); rt.colorSpace = THREE.SRGBColorSpace;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(3200, 3200), new THREE.MeshBasicMaterial({ map: rt })); ground.rotation.x = -Math.PI / 2; ground.position.y = G - .5; scene.add(ground);
}
