// Jogo: cena Three.js (modelo do quarto + cidade), 1ª pessoa com colisão, computador (CSS3D) e sala multiplayer.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { CSS3DRenderer, CSS3DObject } from 'three/addons/renderers/CSS3DRenderer.js';
import { Net } from './net.js';
import { Sfx } from './audio.js';
import { Input } from './input.js';
import { VideoPlayer } from './video.js';
import { Avatar } from './avatar.js';
import { Grid } from './world.js';
import { buildCity } from './city.js';

const $ = s => document.querySelector(s);
const touchDev = matchMedia('(pointer:coarse)').matches;
const lowEnd = touchDev && ((navigator.deviceMemory || 4) <= 4 || (navigator.hardwareConcurrency || 4) <= 4);
const EYE = 1.55, WALK = 1.7, RUN = 3.0, K = 1000; // olhos (m), velocidades (m/s), escala do plano CSS3D
const V = a => new THREE.Vector3(...a);
if (!document.createElement('canvas').getContext('webgl2')) { $('#loadinfo').textContent = 'Seu navegador não suporta WebGL2.'; throw new Error('WebGL2 indisponível'); }

let mode = 'loading', meta, grid, SC, video, mon, lampShade = null, tgl, lockWanted = false, ready = false;
let me = null, roomCode = '', nick = '', pcT = 0, pcDir = 0, spd = 0;
const P = { x: 0, z: 0, yaw: 0, pitch: 0, vx: 0, vz: 0, step: 0, bob: 0 };
const st = { pc: false, lamp: true, light: true };
const others = new Map(), net = new Net(), sfx = new Sfx();
const setMode = m => { mode = m; document.body.dataset.mode = m; };
const toast = (msg, ms = 3200) => { const d = document.createElement('div'); d.textContent = msg; $('#toasts').appendChild(d); setTimeout(() => d.remove(), ms); };
const isTouchUI = () => document.body.classList.contains('touchui');

// ---------------- renderer / cena ----------------
const canvas = $('#gl');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: !touchDev, alpha: true, powerPreference: 'high-performance' });
renderer.setClearColor(0x000000, 0); // canvas transparente: a "tela do monitor" é um furo por onde aparece o plano CSS3D
renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
renderer.shadowMap.enabled = !lowEnd; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene(); scene.fog = new THREE.Fog(0x3a2a55, 90, 720);
const camera = new THREE.PerspectiveCamera(72, 1, .04, 2500);
const cssScene = new THREE.Scene(), cssCam = new THREE.PerspectiveCamera(72, 1, .04 * K, 2500 * K), css = new CSS3DRenderer({ element: $('#css3d') });
const hole = new THREE.MeshBasicMaterial({ color: 0, opacity: 0, blending: THREE.NoBlending, side: THREE.DoubleSide, toneMapped: false, fog: false });

// ---------------- luzes (valores em unidades físicas do Three.js; ajuste aqui se quiser mais claro/escuro) ----------------
const hemi = new THREE.HemisphereLight(0xb9c2ff, 0x5b3d33, 1.05), ceiling = new THREE.PointLight(0xffe0b5, 16, 0, 2);
const lampLight = new THREE.PointLight(0xff9a50, 7, 6, 2), screenLight = new THREE.PointLight(0xbcd4ff, 0, 3, 2), moon = new THREE.DirectionalLight(0x9fb2ff, 2.2);
ceiling.position.set(0, 2.55, 0); moon.position.set(1.5, 8, -12); // luar entrando pela janela (norte)
moon.castShadow = !lowEnd; moon.shadow.mapSize.set(1024, 1024); Object.assign(moon.shadow.camera, { left: -3, right: 3, top: 3, bottom: -3, near: 4, far: 26 });
moon.shadow.camera.updateProjectionMatrix(); moon.shadow.bias = -.0005; moon.shadow.normalBias = .02;
scene.add(hemi, ceiling, lampLight, screenLight, moon, moon.target);
buildCity(scene, lowEnd);
// interruptor de parede (ao lado da porta)
const plate = new THREE.Mesh(new THREE.BoxGeometry(.02, .12, .075), new THREE.MeshStandardMaterial({ color: 0xe9e4da, roughness: .5 }));
tgl = new THREE.Mesh(new THREE.BoxGeometry(.02, .05, .03), new THREE.MeshStandardMaterial({ color: 0xffffff }));
plate.position.set(-1.82, 1.2, .42); tgl.position.set(-1.805, 1.2, .42); scene.add(plate, tgl);

// ---------------- iluminação / computador ----------------
function setLights(s, quiet) {
  const changed = s.lamp !== st.lamp || s.light !== st.light; st.lamp = s.lamp; st.light = s.light;
  ceiling.intensity = st.light ? 16 : 0; hemi.intensity = st.light ? 1.05 : .5; lampLight.intensity = st.lamp ? 7 : 0;
  if (lampShade) lampShade.emissiveIntensity = st.lamp ? .9 : 0;
  tgl.rotation.z = st.light ? .45 : -.45;
  if (changed && !quiet) sfx.switch();
}
function setPower(on, quiet) {
  const changed = on !== st.pc; st.pc = on;
  mon.classList.toggle('on', on); mon.classList.toggle('off', !on); screenLight.intensity = on ? 1.4 : 0;
  if (changed && !quiet) {
    if (on) { mon.classList.add('boot'); setTimeout(() => mon.classList.remove('boot'), 1250); sfx.pcOn(); } else sfx.pcOff();
  }
  video.setPower(on);
}

// ---------------- jogadores ----------------
function addPlayer(p) {
  if (p.id === me?.id || others.has(p.id)) return;
  const a = new Avatar(p.hue, p.name); a.group.visible = p.st.some(v => v !== 0); a.setState(p.st, true);
  scene.add(a.group); others.set(p.id, a);
}
const updateCount = () => { $('#count').textContent = '👥 ' + (others.size + 1); };
async function syncRoom(res) {
  await net.sync();
  for (const a of others.values()) scene.remove(a.group);
  others.clear(); res.players.forEach(addPlayer); updateCount();
  setLights(res, true); setPower(res.pc, true); video.apply(res.video);
}
async function enterRoom(res) {
  me = { id: res.id, name: res.name }; roomCode = res.code;
  $('#roomcode').textContent = $('#pcode').textContent = res.code;
  await syncRoom(res);
  const sp = meta.spawns[(res.players.length - 1) % meta.spawns.length];
  Object.assign(P, { x: sp[0], z: sp[1], yaw: sp[2], pitch: -.05, vx: 0, vz: 0 }); pcT = pcDir = 0;
  setMode('play'); requestLock(); sendState(true);
  toast(res.players.length > 1 ? `Você entrou na sala ${res.code}` : `Sala criada! Código: ${res.code} — envie aos amigos`, 5000);
}
function leaveRoom() {
  net.emit('room:leave'); me = null; roomCode = '';
  for (const a of others.values()) scene.remove(a.group); others.clear();
  lockWanted = false; document.exitPointerLock?.(); pcT = pcDir = 0;
  video.apply(null); setPower(false, true); setMode('menu'); $('#m-main').hidden = false; $('#m-join').hidden = true;
}
let sendT = 0, lastSent = '';
function sendState(force) {
  if (!me) return;
  const a = [+P.x.toFixed(3), +P.z.toFixed(3), +P.yaw.toFixed(3), +P.pitch.toFixed(3), mode === 'pc' || pcT > 0 ? 1 : 0], key = a.join(), t = performance.now();
  if (!force && key === lastSent && t - sendT < 1000) return;
  lastSent = key; sendT = t; net.emit('st', a);
}
net.on('p:join', p => { addPlayer(p); updateCount(); toast(`${p.name} entrou na sala`); })
  .on('p:leave', id => { const a = others.get(id); if (!a) return; scene.remove(a.group); others.delete(id); updateCount(); toast(`${a.name} saiu da sala`); })
  .on('snap', d => {
    for (const id in d) {
      const a = others.get(id); if (!a) continue;
      const first = !a.group.visible; a.group.visible = true;
      if (a.setState(d[id], first)) toast(`${a.name} está usando o computador`);
    }
  })
  .on('v', s => { video.apply(s); })
  .on('pc', ({ pc, video: v }) => { setPower(pc); if (v) video.apply(v); })
  .on('tg', s => setLights(s));
net.s.on('disconnect', () => { if (me) $('#conn').hidden = false; });
net.s.on('connect', async () => { // reconectou: volta para a mesma sala, se ainda existir
  if (!me) return; $('#conn').hidden = true;
  try {
    const res = await net.req('room:join', roomCode, nick);
    if (!res.ok) { toast('A sala foi encerrada.'); return leaveRoom(); }
    me.id = res.id; await syncRoom(res); sendState(true);
  } catch { /* tenta de novo na próxima reconexão */ }
});

// ---------------- interação ----------------
const fwd = new THREE.Vector3(), tmp = new THREE.Vector3(), screenCenter = new THREE.Vector3(), sph = new THREE.Sphere(), frustum = new THREE.Frustum(), pm = new THREE.Matrix4();
let items = [];
function nearest() {
  camera.getWorldDirection(fwd); let best = null;
  for (const it of items) {
    const d = it.p.distanceTo(camera.position); if (d > it.r) continue;
    if (tmp.copy(it.p).sub(camera.position).normalize().dot(fwd) < .35) continue;
    if (!best || d < best.d) best = { ...it, d };
  }
  return best;
}
function interact() {
  if (mode !== 'play' || pcT > 0) return;
  const n = nearest(); if (!n) return; sfx.click();
  if (n.k === 'pc') enterPC(); else net.emit('tg', n.k);
}
function enterPC() {
  lockWanted = false; document.exitPointerLock?.(); P.vx = P.vz = 0; pcDir = 1; setMode('pc');
  if (!st.pc) net.emit('pc', true);
  sendState(true);
}
function exitPC() {
  if (mode !== 'pc') return;
  document.activeElement?.blur?.(); pcDir = -1; setMode('play'); sendState(true); requestLock();
}
function requestLock() {
  if (isTouchUI()) return; lockWanted = true;
  try { canvas.requestPointerLock?.()?.catch?.(() => {}); } catch { /* o clique na tela trava o mouse */ }
}
function openPause() { if (mode !== 'play') return; lockWanted = false; document.exitPointerLock?.(); setMode('pause'); }
function onEsc() { if (mode === 'pc') exitPC(); else if (mode === 'play') openPause(); }
document.addEventListener('pointerlockchange', () => { if (!document.pointerLockElement && lockWanted && mode === 'play') openPause(); });
document.addEventListener('pointerlockerror', () => { lockWanted = false; });
canvas.addEventListener('click', () => { if (mode === 'play' && !document.pointerLockElement) requestLock(); });
const input = new Input(canvas, { interact, esc: onEsc, menu: openPause });
addEventListener('pointerdown', () => sfx.init()); addEventListener('keydown', () => sfx.init());

// ---------------- câmera / loop ----------------
const tE = new THREE.Euler(0, 0, 0, 'YXZ'), bq = new THREE.Quaternion(), bp = new THREE.Vector3(), pcP = new THREE.Vector3(), pcQ = new THREE.Quaternion(), pcM = new THREE.Matrix4();
const cV = new THREE.Vector3(), nV = new THREE.Vector3(), uV = new THREE.Vector3();
function pcPose() { // câmera de frente para a tela, enquadrando o monitor
  const f = THREE.MathUtils.degToRad(camera.fov / 2), d = Math.max((SC.h / 2) / (Math.tan(f) * .8), (SC.w / 2) / (Math.tan(f) * camera.aspect * .8));
  cV.fromArray(SC.c); nV.fromArray(SC.n); uV.fromArray(SC.u);
  pcP.copy(cV).addScaledVector(nV, d); pcM.lookAt(pcP, cV, uV); pcQ.setFromRotationMatrix(pcM);
}
function resize() {
  const w = innerWidth, h = innerHeight;
  renderer.setPixelRatio(Math.min(devicePixelRatio, lowEnd ? 1.25 : touchDev ? 1.5 : 2)); renderer.setSize(w, h, false); css.setSize(w, h);
  camera.aspect = cssCam.aspect = w / h; camera.updateProjectionMatrix(); cssCam.updateProjectionMatrix();
}
addEventListener('resize', resize); addEventListener('orientationchange', () => setTimeout(resize, 250));
let sendAcc = 0, volAcc = 0;
function update(dt) {
  const L = input.takeLook();
  if (mode === 'play' && pcT === 0) {
    P.yaw -= L.x; P.pitch = THREE.MathUtils.clamp(P.pitch - L.y, -1.35, 1.35);
    const m = input.move(), sp = input.run() ? RUN : WALK, k = 1 - Math.exp(-12 * dt);
    const tx = (-Math.sin(P.yaw) * m.y + Math.cos(P.yaw) * m.x) * sp, tz = (-Math.cos(P.yaw) * m.y - Math.sin(P.yaw) * m.x) * sp;
    P.vx += (tx - P.vx) * k; P.vz += (tz - P.vz) * k;
    const nx = P.x + P.vx * dt, nz = P.z + P.vz * dt; // colisão com deslizamento (um eixo por vez)
    if (!grid.blocked(nx, P.z)) P.x = nx; else P.vx = 0;
    if (!grid.blocked(P.x, nz)) P.z = nz; else P.vz = 0;
    spd = Math.hypot(P.vx, P.vz); P.bob += spd * dt * 6; P.step += spd * dt;
    if (P.step > .72) { P.step = 0; sfx.step(); }
  } else if (mode !== 'pc') spd = 0;
  tE.set(P.pitch, P.yaw, 0); bq.setFromEuler(tE); bp.set(P.x, EYE + Math.sin(P.bob) * .012 * Math.min(1, spd / 1.5), P.z);
  if (pcDir) { pcT = THREE.MathUtils.clamp(pcT + pcDir * dt / .7, 0, 1); if (pcT === 0 || pcT === 1) pcDir = 0; }
  if (pcT > 0) { pcPose(); const e = pcT * pcT * (3 - 2 * pcT); camera.position.lerpVectors(bp, pcP, e); camera.quaternion.slerpQuaternions(bq, pcQ, e); }
  else { camera.position.copy(bp); camera.quaternion.copy(bq); }
  for (const a of others.values()) a.update(dt);
  if (me && (sendAcc += dt) > .05) { sendAcc = 0; sendState(); }
  if ((volAcc += dt) > .25) { volAcc = 0; video.setProximity(THREE.MathUtils.clamp(1.15 - camera.position.distanceTo(screenCenter) * .22, .25, 1)); }
  let t = '';
  if (mode === 'play' && pcT === 0) { const n = nearest(); if (n) t = (isTouchUI() ? '✋ AGIR: ' : '[E] ') + n.label(); }
  if ($('#prompt').textContent !== t) $('#prompt').textContent = t;
}
function render() {
  renderer.render(scene, camera);
  camera.updateMatrixWorld(); pm.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse); frustum.setFromProjectionMatrix(pm);
  const show = mode === 'pc' || pcT > 0 || frustum.intersectsSphere(sph); // só desenha o plano CSS3D se a tela estiver no campo de visão
  $('#css3d').style.visibility = show ? 'visible' : 'hidden';
  if (show) { cssCam.position.copy(camera.position).multiplyScalar(K); cssCam.quaternion.copy(camera.quaternion); cssCam.updateMatrixWorld(); css.render(cssScene, cssCam); }
}
let last = performance.now(), skip = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(.05, (now - last) / 1000); last = now;
  if (!ready) return;
  update(dt);
  if ((mode === 'menu' || mode === 'loading') && ++skip % 4) return; // menu: renderiza menos para poupar bateria
  render();
}

// ---------------- carregamento ----------------
async function boot() {
  const [gltf, m] = await Promise.all([
    new GLTFLoader().loadAsync('models/room.glb', e => { $('#pct').textContent = e.total ? Math.round(e.loaded / e.total * 100) + '%' : (e.loaded / 1048576).toFixed(1) + ' MB'; }),
    fetch('models/room.json').then(r => r.json()),
  ]);
  meta = m; SC = m.screen; grid = new Grid(m.grid);
  const aniso = Math.min(renderer.capabilities.getMaxAnisotropy(), touchDev ? 2 : 8);
  gltf.scene.traverse(o => {
    if (!o.isMesh) return;
    o.castShadow = o.receiveShadow = !lowEnd;
    const mt = o.material;
    if (mt.name === 'screen') { o.material = hole; o.castShadow = o.receiveShadow = false; } // tela do monitor = furo para o plano CSS3D
    else { for (const k of ['map', 'normalMap', 'roughnessMap', 'emissiveMap']) if (mt[k]) mt[k].anisotropy = aniso; if (mt.name === 'lamapra') lampShade = mt; }
  });
  scene.add(gltf.scene); lampShade?.emissive.set(0xff7a2a);
  lampLight.position.set(m.lamp[0], m.lamp[1] + .3, m.lamp[2]);
  screenLight.position.copy(V(SC.c)).addScaledVector(V(SC.n), .4); screenCenter.copy(V(SC.c)); sph.set(screenCenter, .8);
  items = [
    { k: 'pc', p: screenCenter, r: 2.4, label: () => (st.pc ? 'Usar o computador' : 'Ligar o computador') },
    { k: 'lamp', p: V(m.lamp), r: 1.5, label: () => (st.lamp ? 'Apagar a luminária' : 'Acender a luminária') },
    { k: 'light', p: plate.position, r: 1.7, label: () => (st.light ? 'Apagar a luz do teto' : 'Acender a luz do teto') },
  ];
  // monitor: a interface HTML vira um plano 3D exatamente sobre a tela do modelo
  const PW = 960; mon = $('#monitor-tpl').content.firstElementChild.cloneNode(true);
  mon.style.width = PW + 'px'; mon.style.height = Math.round(PW * SC.h / SC.w) + 'px';
  const plane = new CSS3DObject(mon);
  plane.position.copy(V(SC.c)).multiplyScalar(K);
  plane.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(V(SC.r), V(SC.u), V(SC.n)));
  plane.scale.setScalar(SC.w * K / PW); cssScene.add(plane);
  video = new VideoPlayer(mon, net, toast);
  setLights(st, true); setPower(false, true);
  Object.assign(P, { x: m.spawns[0][0], z: m.spawns[0][1], yaw: m.spawns[0][2], pitch: -.05 });
  resize(); cssCam.position.set(0, EYE * K, 0); css.render(cssScene, cssCam); // 1ª renderização anexa o monitor ao DOM
  video.init().catch(() => toast('Não foi possível carregar o player do YouTube.'));
  $('#loadinfo').hidden = true; $('#bCreate').disabled = $('#bJoinShow').disabled = false;
  ready = true; setMode('menu');
}

// ---------------- menu ----------------
const err = t => { $('#err').textContent = t || ''; };
const getNick = () => { const v = $('#nick').value.trim(); try { localStorage.setItem('nick', v); } catch { /* ok */ } return v; };
async function copy(text) {
  try { await navigator.clipboard.writeText(text); } catch {
    const t = document.createElement('textarea'); t.value = text; t.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(t); t.select();
    try { document.execCommand('copy'); } catch { /* ok */ } t.remove();
  }
  toast('Copiado: ' + text);
}
try { $('#nick').value = localStorage.getItem('nick') || ''; } catch { /* ok */ }
$('#bCreate').onclick = async () => {
  err(); nick = getNick(); sfx.init(); $('#bCreate').disabled = true;
  try { await enterRoom(await net.req('room:create', nick)); } catch { err('Não foi possível conectar ao servidor. Tente de novo.'); }
  $('#bCreate').disabled = false;
};
$('#bJoinShow').onclick = () => { err(); $('#m-main').hidden = true; $('#m-join').hidden = false; $('#code').focus(); };
$('#bBack').onclick = () => { err(); $('#m-main').hidden = false; $('#m-join').hidden = true; };
$('#code').addEventListener('input', e => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
$('#code').addEventListener('keydown', e => { if (e.key === 'Enter') $('#bJoin').click(); });
$('#bJoin').onclick = async () => {
  const c = $('#code').value.trim(); if (c.length < 6) return err('Digite o código de 6 caracteres da sala.');
  err(); nick = getNick(); sfx.init(); $('#bJoin').disabled = true;
  try {
    const res = await net.req('room:join', c, nick);
    if (!res.ok) err(res.error); else await enterRoom(res);
  } catch { err('Não foi possível conectar ao servidor. Tente de novo.'); }
  $('#bJoin').disabled = false;
};
$('#copy').onclick = () => copy(roomCode); $('#pCopy').onclick = () => copy(roomCode);
$('#pLink').onclick = () => copy(`${location.origin}/?sala=${roomCode}`);
$('#pResume').onclick = () => { setMode('play'); requestLock(); };
$('#pLeave').onclick = leaveRoom;
const link = new URLSearchParams(location.search).get('sala');
if (link) { $('#code').value = link.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6); $('#m-main').hidden = true; $('#m-join').hidden = false; }
setInterval(() => { $('#clock').textContent = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }, 1000);

boot().catch(e => { console.error(e); $('#loadinfo').textContent = 'Erro ao carregar o quarto: ' + e.message; });
requestAnimationFrame(frame);
