// Colisão: grade 2D (vista de cima) gerada do modelo do quarto. true = bloqueado (parede, móvel ou fora do piso).
export class Grid {
  constructor(g) { this.x0 = g.x0; this.c = g.cell; this.n = g.n; this.b = Uint8Array.from(atob(g.data), ch => ch.charCodeAt(0)); }
  blocked(x, z) {
    const ix = Math.floor((x - this.x0) / this.c), iz = Math.floor((z - this.x0) / this.c);
    if (ix < 0 || iz < 0 || ix >= this.n || iz >= this.n) return true;
    const i = iz * this.n + ix;
    return ((this.b[i >> 3] >> (7 - (i & 7))) & 1) === 1;
  }
}
