// Personagem low-poly dos outros jogadores: corpo, cabeça que acompanha o olhar, pernas/braços animados e nome flutuante.
import * as THREE from 'three';
function label(text) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64; const g = c.getContext('2d');
  g.font = 'bold 30px system-ui,sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  const w = Math.min(248, g.measureText(text).width + 30); g.fillStyle = 'rgba(15,10,30,.75)';
  if (g.roundRect) { g.beginPath(); g.roundRect((256 - w) / 2, 8, w, 48, 18); g.fill(); } else g.fillRect((256 - w) / 2, 8, w, 48);
  g.fillStyle = '#fff'; g.fillText(text, 128, 33);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true })); s.scale.set(.8, .2, 1); return s;
}
export class Avatar {
  constructor(hue, name) {
    this.name = name; this.using = false; this.speed = 0; this.t = 0; this.target = [0, 0, 0, 0, 0];
    const g = this.group = new THREE.Group();
    const mk = (color, r = .85) => new THREE.MeshStandardMaterial({ color, roughness: r, flatShading: true });
    const cloth = mk(new THREE.Color().setHSL(hue / 360, .6, .52)), skin = mk(0xf0c8a0, .9), dark = mk(0x2a1d36);
    const add = (geo, mat, x, y, z, parent = g) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; };
    add(new THREE.CylinderGeometry(.16, .19, .56, 8), cloth, 0, .98, 0);
    this.head = new THREE.Group(); this.head.position.set(0, 1.5, 0); g.add(this.head);
    add(new THREE.IcosahedronGeometry(.15, 1), skin, 0, 0, 0, this.head);
    add(new THREE.SphereGeometry(.16, 8, 6, 0, Math.PI * 2, 0, Math.PI * .55), dark, 0, .03, .01, this.head); // cabelo
    for (const x of [-.055, .055]) add(new THREE.SphereGeometry(.026, 6, 6), dark, x, .01, -.135, this.head); // olhos (frente = -Z)
    this.legs = [-.08, .08].map(x => { const p = new THREE.Group(); p.position.set(x, .72, 0); g.add(p); add(new THREE.BoxGeometry(.11, .7, .12), dark, 0, -.35, 0, p); return p; });
    this.arms = [-.23, .23].map(x => { const p = new THREE.Group(); p.position.set(x, 1.22, 0); g.add(p); add(new THREE.BoxGeometry(.08, .5, .09), cloth, 0, -.24, 0, p); return p; });
    this.setLabel();
  }
  setLabel() {
    if (this.sprite) { this.group.remove(this.sprite); this.sprite.material.map.dispose(); this.sprite.material.dispose(); }
    this.sprite = label(this.name + (this.using ? ' 💻' : '')); this.sprite.position.y = 1.95; this.group.add(this.sprite);
  }
  setState(st, snap) { // st = [x, z, yaw, pitch, flags]; retorna true se começou a usar o computador
    this.target = st; const u = !!(st[4] & 1), started = u && !this.using;
    if (u !== this.using) { this.using = u; this.setLabel(); }
    if (snap) { this.group.position.set(st[0], 0, st[1]); this.group.rotation.y = st[2]; }
    return started;
  }
  update(dt) {
    const [tx, tz, yaw, pitch] = this.target, g = this.group, dx = tx - g.position.x, dz = tz - g.position.z, dist = Math.hypot(dx, dz), k = 1 - Math.exp(-14 * dt);
    if (dist > 2.5) g.position.set(tx, 0, tz); else { g.position.x += dx * k; g.position.z += dz * k; }
    let d = yaw - g.rotation.y; d = Math.atan2(Math.sin(d), Math.cos(d)); g.rotation.y += d * k;
    this.head.rotation.x += (pitch - this.head.rotation.x) * k;
    this.speed += (Math.min(dist * 14, 3.2) - this.speed) * Math.min(1, dt * 10);
    this.t += dt * Math.max(this.speed, 0) * 5;
    const sw = Math.sin(this.t) * Math.min(1, this.speed / 1.2) * .7;
    this.legs[0].rotation.x = sw; this.legs[1].rotation.x = -sw; this.arms[0].rotation.x = -sw; this.arms[1].rotation.x = sw;
  }
}
