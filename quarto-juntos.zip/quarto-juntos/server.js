// Servidor HTTP (arquivos do jogo + three.js) e Socket.IO (salas, jogadores, vídeo).
const path = require('path'), http = require('http');
const express = require('express'), compression = require('compression'), { Server } = require('socket.io');

const app = express();
app.use(compression());
app.use('/vendor/three', express.static(path.join(__dirname, 'node_modules/three'), { maxAge: '7d' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));
app.get('/health', (_, res) => res.send('ok'));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true }, pingInterval: 10000, pingTimeout: 15000 });
require('./src/rooms')(io);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Quarto Juntos rodando em http://localhost:${PORT}`));
