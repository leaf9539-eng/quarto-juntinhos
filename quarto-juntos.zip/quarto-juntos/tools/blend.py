import gzip,struct,re,numpy as np
FMT={'char':'b','uchar':'B','short':'h','ushort':'H','int':'i','uint':'I','float':'f','double':'d','int64_t':'q','uint64_t':'Q'}
class Blend:
    def __init__(s,path):
        d=gzip.open(path).read(); s.d=d
        s.ps=8 if d[7:8]==b'-' else 4; s.E='<' if d[8:9]==b'v' else '>'; s.ver=d[9:12].decode()
        pos=12; s.blocks=[]; s.by={}
        while pos<len(d):
            code=d[pos:pos+4]; size=struct.unpack_from(s.E+'i',d,pos+4)[0]
            if s.ps==8: old,sd,n=struct.unpack_from(s.E+'Qii',d,pos+8); h=24
            else: old,sd,n=struct.unpack_from(s.E+'Iii',d,pos+8); h=20
            b=(code,size,old,sd,n,pos+h); s.blocks.append(b); s.by[old]=b; pos+=h+size
            if code==b'ENDB': break
        b=[x for x in s.blocks if x[0]==b'DNA1'][0]; o=b[5]; E=s.E
        def al(p): return o+((p-o+3)&~3)
        p=o+8; n=struct.unpack_from(E+'i',d,p)[0]; p+=4; names=[]
        for i in range(n): e=d.index(b'\0',p); names.append(d[p:e].decode()); p=e+1
        p=al(p)+4; n=struct.unpack_from(E+'i',d,p)[0]; p+=4; types=[]
        for i in range(n): e=d.index(b'\0',p); types.append(d[p:e].decode()); p=e+1
        p=al(p)+4; tl=list(struct.unpack_from(E+'%dH'%n,d,p)); p=al(p+2*n)+4
        n=struct.unpack_from(E+'i',d,p)[0]; p+=4; s.sn=[]; s.info={}
        for i in range(n):
            t,nf=struct.unpack_from(E+'HH',d,p); p+=4; off=0; fl=[]
            for j in range(nf):
                ti,ni=struct.unpack_from(E+'HH',d,p); p+=4; nm=names[ni]
                ptr=nm.startswith('*') or nm.startswith('(*'); cnt=1
                for x in re.findall(r'\[(\d+)\]',nm): cnt*=int(x)
                sz=s.ps if ptr else tl[ti]; cl=re.sub(r'\[\d+\]|[*()]','',nm)
                fl.append((cl,types[ti],off,cnt,ptr)); off+=sz*cnt
            s.sn.append(types[t]); s.info[types[t]]=(tl[t],fl)
    def S(s,t,o): return Obj(s,t,o)
    def blk(s,ptr):
        b=s.by.get(ptr); return b
    def at(s,ptr,i=0):
        b=s.by[ptr]; t=s.sn[b[3]]; return Obj(s,t,b[5]+i*s.info[t][0])
    def ids(s,code):
        r=[]
        for b in s.blocks:
            if b[0][:2]==code.encode():
                t=s.sn[b[3]]; 
                for i in range(b[4]): r.append(Obj(s,t,b[5]+i*s.info[t][0]))
        return r
class Obj:
    def __init__(s,b,t,o): s.b=b; s.t=t; s.o=o
    def __getitem__(s,k):
        b=s.b
        for nm,ty,off,cnt,ptr in b.info[s.t][1]:
            if nm==k: break
        else: raise KeyError(k)
        o=s.o+off
        if ptr:
            v=struct.unpack_from(b.E+('Q' if b.ps==8 else 'I')*cnt,b.d,o); return v[0] if cnt==1 else v
        f=FMT.get(ty)
        if ty=='char' and cnt>1: return b.d[o:o+cnt].split(b'\0')[0].decode('latin1')
        if f: v=struct.unpack_from(b.E+f*cnt,b.d,o); return v[0] if cnt==1 else v
        return Obj(b,ty,o)
    def name(s): return s['id']['name'][2:]
