from blend import *
def mesh_of(b,o):
    me=b.at(o['data']); nv=me['totvert']; M=np.array(o['obmat']).reshape(4,4)
    def layer(sname,dt,cnt,name=None):
        for L in (me['vdata'],me['ldata'],me['pdata'],me['edata']):
            lay=b.blk(L['layers'])
            if not lay: continue
            for i in range(lay[4]):
                l=Obj(b,'CustomDataLayer',lay[5]+i*b.info['CustomDataLayer'][0])
                p=l['data']
                if p in b.by and b.sn[b.by[p][3]]==sname and (name is None or l['name']==name): return np.frombuffer(b.d,dtype=dt,count=cnt,offset=b.by[p][5])
    vs=layer('MVert',[('co','<f4',3),('no','<i2',3),('f','u1'),('w','u1')],nv)
    lp=layer('MLoop',[('v','<u4'),('e','<u4')],me['totloop'])
    pl=layer('MPoly',[('ls','<i4'),('n','<i4'),('m','<i2'),('f','u1'),('p','u1')],me['totpoly'])
    uv=layer('MLoopUV',[('uv','<f4',2),('f','<i4')],me['totloop'])
    mp=b.blk(me['mat']); mats=[b.at(x) for x in struct.unpack_from('<%dQ'%me['totcol'],b.d,mp[5])] if mp else []
    return vs,lp,pl,uv,mats,M
