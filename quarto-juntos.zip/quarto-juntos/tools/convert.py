# Converte o .blend do quarto (Blender 2.9x) em GLB + room.json (colisão, tela do monitor, pontos de entrada).
# Requer: python3, numpy, pillow, scipy
import json,struct,base64,io,os,math,numpy as np
from PIL import Image
from scipy import ndimage as ndi
from load import *
import sys
SRC=sys.argv[1]; TX=sys.argv[2].rstrip('/')+'/'; OUT=sys.argv[3].rstrip('/')+'/'  # uso: convert.py modelo.blend pasta_texturas pasta_saida
S=0.4; CX,CY,FZ=0.335,-0.38,-0.37; H=(6.86-FZ)*S
b=Blend(SRC)
def lst(lb):
    r=[];p=lb['first']
    while p: n=b.at(p); r.append((p,n)); p=n['next']
    return r
def sv(s):
    o=b.by[s['default_value']][5]
    return struct.unpack_from('<4f',b.d,o) if s['type']==2 else struct.unpack_from('<f',b.d,o+4)[0]
def IMG(name):
    st=os.path.splitext(name.replace('\\','/').split('/')[-1])[0]
    for f in os.listdir(TX):
        fs=os.path.splitext(f)[0]
        if st.startswith(fs) or fs.startswith(st): return TX+f
def parse_mat(m):
    d={'name':m.name(),'base':[.8,.8,.8,1.],'rough':.8,'metal':0.}
    if not m['nodetree']: return d
    t=b.at(m['nodetree']); nodes=dict(lst(t['nodes'])); ins={}
    for _,l in lst(t['links']): ins[(l['tonode'],b.at(l['tosock'])['name'])]=l['fromnode']
    sk=lambda p:{s['name']:s for _,s in lst(nodes[p]['inputs'])}
    img=lambda p:(IMG(b.at(nodes[p]['id'])['name']) if nodes[p]['idname']=='ShaderNodeTexImage' and nodes[p]['id'] else None)
    for p,n in nodes.items():
        k=sk(p); t=n['idname']
        if t=='ShaderNodeBsdfPrincipled':
            d['base']=list(sv(k['Base Color'])); d['rough']=sv(k['Roughness']); d['metal']=sv(k['Metallic'])
            if (p,'Base Color') in ins:
                f=ins[(p,'Base Color')]
                if nodes[f]['idname']=='ShaderNodeMixRGB':
                    kk=sk(f); d['mix']=(sv(kk['Fac']),sv(kk['Color2'])); f=ins.get((f,'Color1'))
                d['alb']=img(f) if f else None
            if (p,'Roughness') in ins: d['rgh']=img(ins[(p,'Roughness')])
            if (p,'Normal') in ins:
                nm=ins[(p,'Normal')]; d['nrm']=img(ins[(nm,'Color')]) if (nm,'Color') in ins else None
        if t=='ShaderNodeEmission':
            d['emit']=list(sv(k['Color'])[:3]); d['base']=[0,0,0,1.]
            if (p,'Color') in ins: d['emtex']=img(ins[(p,'Color')])
    return d
MATS={m.name():parse_mat(m) for m in b.ids('MA')}
MATS['default']={'name':'default','base':[.85,.85,.85,1.],'rough':.9,'metal':0.}
# ---- glb builder
bin_=bytearray(); BV=[];AC=[];IM=[];TXs=[];GM=[];cache={}
def view(data,target=None):
    while len(bin_)%4: bin_.append(0)
    d={'buffer':0,'byteOffset':len(bin_),'byteLength':len(data)}; bin_.extend(data)
    if target: d['target']=target
    BV.append(d); return len(BV)-1
def acc(a,ct,ty,target,mm=False):
    a=np.ascontiguousarray(a); d={'bufferView':view(a.tobytes(),target),'componentType':ct,'count':len(a),'type':ty}
    if mm: d['min']=a.min(0).tolist(); d['max']=a.max(0).tolist()
    AC.append(d); return len(AC)-1
def tex(key,fn):
    if key not in cache:
        IM.append({'bufferView':view(fn()),'mimeType':'image/jpeg'}); TXs.append({'source':len(IM)-1,'sampler':0}); cache[key]=len(TXs)-1
    return {'index':cache[key]}
def jpg(a,q): bf=io.BytesIO(); Image.fromarray(a).save(bf,'JPEG',quality=q); return bf.getvalue()
def rs(im,n): return im.resize((n,n),Image.LANCZOS) if max(im.size)>n else im
def lin(a): return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def srgb(a): return np.where(a<=.0031308,a*12.92,1.055*np.maximum(a,0)**(1/2.4)-.055)
def gmat(name):
    d=MATS[name]; pm={'baseColorFactor':d['base'],'metallicFactor':d['metal'],'roughnessFactor':d['rough']}; g={'name':name}
    if d.get('alb'):
        def f():
            a=np.asarray(rs(Image.open(d['alb']).convert('RGB'),1024),np.float32)/255
            if 'mix' in d: fc,c2=d['mix']; a=srgb(lin(a)*(1-fc)+np.array(c2[:3])*fc)
            return jpg((np.clip(a,0,1)*255).astype(np.uint8),85)
        pm['baseColorTexture']=tex(('a',d['alb'],str(d.get('mix'))),f); pm['baseColorFactor']=[1,1,1,1]
    if d.get('rgh'):
        def f():
            L=np.asarray(rs(Image.open(d['rgh']).convert('L'),512)); return jpg(np.dstack([np.full_like(L,255),L,np.zeros_like(L)]),85)
        pm['metallicRoughnessTexture']=tex(('r',d['rgh']),f); pm['roughnessFactor']=1.; pm['metallicFactor']=0.
    if d.get('nrm'): g['normalTexture']=tex(('n',d['nrm']),lambda:jpg(np.asarray(rs(Image.open(d['nrm']).convert('RGB'),512)),90))
    if 'emit' in d:
        g['emissiveFactor']=d['emit']
        if d.get('emtex'): g['emissiveTexture']=tex(('e',d['emtex']),lambda:jpg(np.asarray(rs(Image.open(d['emtex']).convert('RGB'),1024)),85)); g['emissiveFactor']=[1,1,1]
    g['pbrMetallicRoughness']=pm; GM.append(g); return len(GM)-1
MI={}
def mid(n):
    if n not in MI: MI[n]=gmat(n)
    return MI[n]
# ---- geometry
prims={}  # objname -> list of (matname,P,N,U,I)
COL=[]; META={}; EXC={'Papel','Papeles','Alfombrilla'}
for o in b.ids('OB'):
    if o['type']!=1: continue
    on=o.name(); vs,lp,pl,uv,mats,M=mesh_of(b,o)
    V=vs['co'].astype(np.float64); Wd=(np.c_[V,np.ones(len(V))]@M)[:,:3]
    Fp=np.c_[(Wd[:,0]-CX)*S,(Wd[:,2]-FZ)*S,-(Wd[:,1]-CY)*S]
    ls,n=pl['ls'],pl['n']; tl=[];tp=[]
    for k in range(1,n.max()-1):
        sel=np.where(n>k+1)[0]; tl.append(np.c_[ls[sel],ls[sel]+k,ls[sel]+k+1]); tp.append(sel)
    TL=np.vstack(tl); TP=np.concatenate(tp)
    if np.linalg.det(M[:3,:3])<0: TL=TL[:,[0,2,1]]
    VI=lp['v'][TL].astype(np.int64); P=Fp[VI]; fn=np.cross(P[:,1]-P[:,0],P[:,2]-P[:,0])
    vn=np.zeros((len(V),3))
    for c in range(3): np.add.at(vn,VI[:,c],fn)
    sm=(pl['f'][TP]&1)==1; nrm=lambda a:a/(np.linalg.norm(a,axis=-1,keepdims=True)+1e-12)
    CN=np.where(sm[:,None,None],nrm(vn[VI]),nrm(fn)[:,None,:])
    UV=uv['uv'][TL].astype(np.float64) if uv is not None else np.zeros((len(TL),3,2)); UV[...,1]=1-UV[...,1]
    mi=np.clip(pl['m'][TP],0,max(len(mats)-1,0)); out=[]
    if on!='Habitacion' or True: 
        if on not in EXC:
            T=P; ok=(T[:,:,1].max(1)>.12)&(T[:,:,1].min(1)<1.7); COL.append(T[ok])
    for g in np.unique(mi):
        r=np.where(mi==g)[0]; mname=mats[g].name() if mats else 'default'
        ids=np.where(sm[r,None],VI[r],-(1+np.arange(len(r)))[:,None]).reshape(-1)
        key=np.c_[ids,np.round(UV[r].reshape(-1,2)*8192).astype(np.int64)]
        _,fi,inv=np.unique(key,axis=0,return_index=True,return_inverse=True)
        out.append((mname,P[r].reshape(-1,3)[fi],CN[r].reshape(-1,3)[fi],UV[r].reshape(-1,2)[fi],inv.reshape(-1).astype(np.uint32)))
        if on=='Pantalla' and mname=='screen':
            q=P[r].reshape(-1,3); u=UV[r].reshape(-1,2); top=q[u[:,1]<u[:,1].min()+1e-4+(u[:,1].max()-u[:,1].min())*.01]; bot=q[u[:,1]>u[:,1].max()-(u[:,1].max()-u[:,1].min())*.01]
            ctr=q.mean(0); nn=nrm(CN[r].reshape(-1,3).mean(0))
            if np.dot(nn,-ctr*np.array([1,0,1]))<0: nn=-nn
            ud=nrm(np.array([0,1,0])-nn*nn[1]); rr=np.cross(ud,nn); META['screen']={'c':ctr.tolist(),'r':rr.tolist(),'u':ud.tolist(),'n':nn.tolist(),'w':float(np.ptp(q@rr)),'h':float(np.ptp(q@ud))}
    if on=='Lampara': META['lamp']=Fp.mean(0).tolist()
    prims[on]=out
# wall uv map from original wall triangle
hab=[x for x in b.ids('OB') if x.name()=='Habitacion'][0]; vs,lp,pl,uv,mats,M=mesh_of(b,hab)
best=None
for i in range(len(pl)):
    if mats[pl[i]['m']].name()!='pared': continue
    ix=lp['v'][pl[i]['ls']:pl[i]['ls']+3]; q=(np.c_[vs['co'][ix],np.ones(3)]@M)[:,:3]; nn=np.cross(q[1]-q[0],q[2]-q[0]); a=np.linalg.norm(nn)
    if abs(nn[0])>.95*a and (best is None or a>best[0]): best=(a,q,uv['uv'][pl[i]['ls']:pl[i]['ls']+3])
q,u=best[1],best[2]; A=np.linalg.lstsq(np.c_[q[:,1],q[:,2],np.ones(3)],u,rcond=None)[0][:2]
def box(mn,mx,mat,flat=False):
    Pp=[];Nn=[];Uu=[];Ii=[]
    for a in range(3):
        b_,c_=(a+1)%3,(a+2)%3
        for s in(1,-1):
            qd=[]
            for i,j in((0,0),(1,0),(1,1),(0,1)):
                p=[0,0,0]; p[a]=mx[a] if s>0 else mn[a]; p[b_]=mx[b_] if i else mn[b_]; p[c_]=mx[c_] if j else mn[c_]; qd.append(p)
            nv=[0,0,0]; nv[a]=s; qd=qd if s>0 else qd[::-1]; bs=len(Pp)
            for p in qd:
                h=p[2] if a==0 else p[0]; vv=p[1]/S if a!=1 else p[2]/S; hh=h/S if a!=1 else p[0]/S
                Pp.append(p); Nn.append(nv); Uu.append([0,0] if flat else (np.array([hh,vv])@A).tolist())
            Ii+=[bs,bs+1,bs+2,bs,bs+2,bs+3]
    return (mat,np.array(Pp),np.array(Nn),np.array(Uu),np.array(Ii,np.uint32))
f=1.83;t=.19;top=(6.86-FZ)*S
prims['ParedLeste']=[box([f,-.2,-f-t],[f+t,top,f+t],'pared')]; prims['ParedSul']=[box([-f-t,-.2,f],[f,top,f+t],'pared')]
prims['Teto']=[box([-f-t,top,-f-t],[f+t,top+.12,f+t],'afuera',True)]
# ---- write glb
nodes=[];meshes=[]
for on,pr in prims.items():
    ps=[]
    for mname,P,N,U,I in pr:
        ps.append({'attributes':{'POSITION':acc(P.astype(np.float32),5126,'VEC3',34962,True),'NORMAL':acc(N.astype(np.float32),5126,'VEC3',34962),'TEXCOORD_0':acc(U.astype(np.float32),5126,'VEC2',34962)},'indices':acc(I.astype(np.uint32),5125,'SCALAR',34963),'material':mid(mname)})
    meshes.append({'name':on,'primitives':ps}); nodes.append({'name':on,'mesh':len(meshes)-1})
js={'asset':{'version':'2.0','generator':'blend2glb'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':GM,'textures':TXs,'images':IM,'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}],'bufferViews':BV,'accessors':AC,'buffers':[{'byteLength':len(bin_)}]}
jb=json.dumps(js,separators=(',',':')).encode(); jb+=b' '*(-len(jb)%4)
while len(bin_)%4: bin_.append(0)
open(OUT+'room.glb','wb').write(b'glTF'+struct.pack('<II',2,28+len(jb)+len(bin_))+struct.pack('<I',len(jb))+b'JSON'+jb+struct.pack('<I',len(bin_))+b'BIN\0'+bytes(bin_))
# ---- collision grid
T=np.vstack(COL); C=.05; X0=-2.2; N=88
e=np.max([np.linalg.norm(T[:,1]-T[:,0],axis=1),np.linalg.norm(T[:,2]-T[:,1],axis=1),np.linalg.norm(T[:,0]-T[:,2],axis=1)],0)
sm_=e<C*.7; pts=[T[sm_].reshape(-1,3),T[sm_].mean(1)]
for tr,ee in zip(T[~sm_],e[~sm_]):
    k=int(np.ceil(ee/(C*.5))); i,j=np.meshgrid(np.arange(k+1),np.arange(k+1)); m=i+j<=k; a,bb=(i[m]/k)[:,None],(j[m]/k)[:,None]; pts.append(tr[0]+a*(tr[1]-tr[0])+bb*(tr[2]-tr[0]))
pts=np.vstack(pts); g=np.zeros((N,N),bool); ix=np.clip(((pts[:,0]-X0)/C).astype(int),0,N-1); iz=np.clip(((pts[:,2]-X0)/C).astype(int),0,N-1); g[iz,ix]=True
cc=X0+(np.arange(N)+.5)*C; fx=(np.abs(cc)<f)[None,:]&(np.abs(cc)<f)[:,None]
blocked=ndi.binary_dilation(~fx|g,(lambda y,x:(x*x+y*y)<=4.0**2)(*np.ogrid[-5:6,-5:6]))
lab,nl=ndi.label(~blocked); big=np.argmax(np.bincount(lab.ravel())[1:])+1; dist=ndi.distance_transform_edt(lab==big)
sp=[]
for idx in np.argsort(-dist.ravel()):
    z_,x_=divmod(idx,N); p=(cc[x_],cc[z_])
    if dist[z_,x_]<3: break
    if all(math.hypot(p[0]-s[0],p[1]-s[1])>.7 for s in sp): sp.append(p)
    if len(sp)>=8: break
META['spawns']=[[round(float(x),3),round(float(z),3),round(math.atan2(x,z),3)] for x,z in sp]
META['grid']={'x0':X0,'cell':C,'n':N,'data':base64.b64encode(np.packbits(blocked.ravel()).tobytes()).decode()}
META['height']=H; META['floor']=f
json.dump(META,open(OUT+'room.json','w'),separators=(',',':'))
print('glb KB',os.path.getsize(OUT+'room.glb')//1024,'imgs',len(IM),'mats',[g_['name'] for g_ in GM]); print('screen',{k:(np.round(v,3).tolist() if k!='w' and k!='h' else round(v,3)) for k,v in META['screen'].items()}); print('lamp',np.round(META['lamp'],2),'spawns',META['spawns'][:4],'blocked',blocked.mean().round(2),'pm',MATS['pared'].get('mix'))
