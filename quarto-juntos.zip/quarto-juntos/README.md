# Quarto Juntos

Quarto 3D multiplayer (Three.js + WebGL2) com **salas privadas por código** e um **computador que toca vídeos do YouTube sincronizados** para todos da sala. O cenário é o seu modelo `low-poly-isometric-room`, convertido do `.blend` para GLB sem mudar o visual.

## Rodar
Precisa de Node.js 18+.
```bash
npm install
npm start          # http://localhost:3000
npm test           # testa salas/sincronização e a colisão do modelo
```
Abra o endereço, digite um nome e use **CRIAR SALA** (o servidor gera o código, ex.: `X7K92P`) ou **ENTRAR EM UMA SALA** (digite o código do amigo).

## Jogar com amigos pela internet
O servidor precisa estar acessível aos amigos. Duas opções:
1. **Hospedar** (Render, Railway, Fly.io…): *Build* `npm install`, *Start* `npm start`. A porta vem da variável `PORT` (já tratada). Prefira HTTPS: o YouTube é mais estável assim.
2. **Túnel rápido**: com o servidor rodando, `npx cloudflared tunnel --url http://localhost:3000` (ou ngrok) e envie o link aos amigos.

O botão **Copiar link de convite** (menu de pausa) gera `…/?sala=CÓDIGO` já preenchido.

## Controles
| | PC | Celular/tablet |
|---|---|---|
| Andar | W A S D (Shift corre) | joystick à esquerda |
| Olhar | mouse | arrastar o dedo à direita |
| Interagir | E | botão AGIR |
| Menu / sair do computador | ESC | ☰ / ← VOLTAR |

Interações perto de cada objeto: **computador** (liga e abre o player), **luminária** da mesa de cabeceira e **interruptor** ao lado da porta (as luzes são compartilhadas na sala).

Teclado físico: o navegador não avisa quando um teclado é conectado/desconectado, então o jogo infere por eventos reais de teclado/mouse. Ao detectar, os controles virtuais somem; se você tocar na tela e o teclado ficar inativo por ~5 s, eles voltam. Toque e teclado funcionam juntos.

## Como funciona
- `tools/convert.py` lê o `.blend` (Blender 2.9x), aplica escala 0,4 m/unidade e gera `public/models/room.glb` (geometria, UVs, texturas e materiais originais) e `room.json` (grade de colisão, posição da tela do monitor, pontos de entrada). Para refazer: `python3 tools/convert.py modelo.blend pasta_texturas public/models` (precisa de `numpy pillow scipy`).
- Colisão: grade 2D do piso gerada da geometria real (paredes e móveis bloqueiam; não dá para sair pelas laterais abertas).
- Monitor: a tela do modelo é um "furo" no canvas WebGL e a interface do player é um plano CSS3D exatamente sobre ela, então o vídeo aparece em perspectiva de qualquer ângulo. Interface dentro da tela: link, **CARREGAR VÍDEO**, pausar/continuar, barra de tempo, volume (cai com a distância), tela cheia e desligar.
- Vídeo sincronizado: o servidor guarda `{id, tocando, posição, hora do servidor}`; cada cliente calcula a posição atual com o relógio do servidor e corrige desvios > 1 s. Quem entra depois recebe o vídeo e a posição atual. Vídeos que proíbem incorporação mostram mensagem de erro.
- Servidor (`src/rooms.js`): códigos de 6 caracteres sem 0/O/1/I, salas isoladas, sala some quando o último sai, posições dos jogadores a 20 Hz.

## Ajustes rápidos
- Brilho das luzes: constantes no começo de `public/js/main.js` (`hemi`, `ceiling`, `lampLight`, `moon`).
- O modelo original é uma maquete aberta (duas paredes, sem teto). Para o modo em 1ª pessoa o `convert.py` **adiciona** as duas paredes que faltam (mesmo material) e um teto; nada do original foi removido. Para não adicionar, apague as linhas `prims['ParedLeste']…prims['Teto']` do script e converta de novo.
- Sombras e resolução são reduzidas automaticamente em celulares mais fracos.
