// Testes dos módulos do cliente que não dependem do navegador: links do YouTube e colisão no modelo.
import assert from 'node:assert'; import { readFileSync } from 'node:fs';
import { parseVideoId } from '../public/js/video.js'; import { Grid } from '../public/js/world.js';
const ID = 'dQw4w9WgXcQ';
for (const u of [`https://www.youtube.com/watch?v=${ID}`, `https://youtube.com/watch?v=${ID}&t=42s`, `https://youtu.be/${ID}?si=abc`, `https://m.youtube.com/watch?v=${ID}`,
  `https://www.youtube.com/embed/${ID}`, `https://www.youtube.com/shorts/${ID}`, `https://www.youtube.com/live/${ID}`, `www.youtube.com/watch?v=${ID}`, ID, `  https://music.youtube.com/watch?v=${ID}  `])
  assert.equal(parseVideoId(u), ID, u);
for (const u of ['', 'texto qualquer', 'https://vimeo.com/123456789', 'https://www.youtube.com/', 'https://youtube.com.evil.com/watch?v=' + ID]) assert.equal(parseVideoId(u), null, u);
const meta = JSON.parse(readFileSync(new URL('../public/models/room.json', import.meta.url))), g = new Grid(meta.grid);
for (const [x, z] of meta.spawns) assert(!g.blocked(x, z), `spawn bloqueado ${x},${z}`);
assert(g.blocked(0, 5) && g.blocked(-5, 0) && g.blocked(1.9, 0), 'fora do piso deve bloquear');
assert(g.blocked(1.2, 0), 'a cama deve bloquear'); assert(g.blocked(-1.4, -0.7), 'a mesa deve bloquear');
// o jogador consegue chegar perto o bastante do computador (raio de interação 2,4 m)
const c = meta.screen.c; let best = 9; for (let x = -2; x < 2; x += .05) for (let z = -2; z < 2; z += .05) if (!g.blocked(x, z)) best = Math.min(best, Math.hypot(x - c[0], z - c[2]));
assert(best < 1.6, 'distância mínima até a tela: ' + best);
console.log(`OK: links do YouTube, colisão (${meta.spawns.length} pontos de entrada) e alcance do computador (${best.toFixed(2)} m)`);
