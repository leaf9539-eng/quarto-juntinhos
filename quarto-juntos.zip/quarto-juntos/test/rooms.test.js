// Teste da lógica das salas com um Socket.IO simulado (sem rede).
const assert = require('assert'), attach = require('../src/rooms');
const sockets = [], chans = new Map(); let handlers = {};
const io = { on: (e, f) => (handlers[e] = f), to: c => ({ emit: (e, d) => (chans.get(c) || []).forEach(s => s.got.push([e, d])), volatile: { emit: (e, d) => (chans.get(c) || []).forEach(s => s.got.push([e, d])) } }) };
const { rooms } = attach(io);
function sock(id) {
  const s = { id, data: {}, got: [], h: {}, on(e, f) { this.h[e] = f; }, join(c) { chans.set(c, [...(chans.get(c) || []), s]); }, leave(c) { chans.set(c, (chans.get(c) || []).filter(x => x !== s)); }, to: c => ({ emit: (e, d) => (chans.get(c) || []).filter(x => x !== s).forEach(x => x.got.push([e, d])) }), call(e, ...a) { return new Promise(r => { this.h[e](...a, r); }); } };
  handlers.connection(s); sockets.push(s); return s;
}
(async () => {
  const a = sock('A'), b = sock('B'), c = sock('C');
  const ra = await a.call('room:create', 'Ana'); assert(ra.ok && /^[A-Z2-9]{6}$/.test(ra.code));
  const r0 = await b.call('room:join', 'ZZZZZZ', 'Bia'); assert(!r0.ok && /não encontrada/.test(r0.error));
  const rb = await b.call('room:join', ' ' + ra.code.toLowerCase() + ' ', 'Bia'); assert(rb.ok && rb.players.length === 2);
  assert(a.got.some(([e, d]) => e === 'p:join' && d.name === 'Bia'));
  const rc = await c.call('room:create', 'Caio'); assert(rc.code !== ra.code);          // salas isoladas
  a.h.st([1, 2, 3, .5, 1]); await new Promise(r => setTimeout(r, 120));
  assert(b.got.some(([e, d]) => e === 'snap' && d.A[0] === 1 && d.A[4] === 1)); assert(!c.got.some(([e]) => e === 'snap'));
  a.h['v:load']('dQw4w9WgXcQ'); assert(rooms.get(ra.code).video.playing);
  a.h['v:load']('invalido'); assert.equal(rooms.get(ra.code).video.id, 'dQw4w9WgXcQ');
  await new Promise(r => setTimeout(r, 1100)); b.h['v:pause'](); const v = rooms.get(ra.code).video;
  assert(!v.playing && v.pos > 0.9 && v.pos < 1.6, 'pausa guarda a posição: ' + v.pos);
  const d = sock('D'); const rd = await d.call('room:join', ra.code, 'Dani'); assert.equal(rd.video.id, 'dQw4w9WgXcQ'); assert.equal(rd.video.playing, false);
  d.h['v:seek'](42); d.h['v:play'](); assert(rooms.get(ra.code).video.playing && rooms.get(ra.code).video.pos >= 42);
  a.h.tg('lamp'); assert.equal(rooms.get(ra.code).lamp, false); a.h.pc(false); assert.equal(rooms.get(ra.code).pc, false);
  [a, b, d].forEach(s => s.h.disconnect()); assert(!rooms.has(ra.code), 'sala encerrada com o último jogador'); assert(rooms.has(rc.code));
  console.log('OK: salas, códigos, isolamento, sincronização de jogadores e do vídeo'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
