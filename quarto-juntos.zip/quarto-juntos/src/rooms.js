'use strict';
// Toda a lógica de salas. O servidor é a fonte da verdade: códigos, jogadores, estado do vídeo, luzes e computador.
const crypto = require('crypto');
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sem 0/O/1/I para evitar confusão ao digitar
const clean = n => String(n || '').replace(/[^\p{L}\p{N} _.-]/gu, '').trim().slice(0, 16) || 'Jogador';
const num = (v, lim) => (Number.isFinite(v) ? Math.max(-lim, Math.min(lim, v)) : 0);
const cur = v => (!v ? 0 : v.playing ? v.pos + (Date.now() - v.at) / 1000 : v.pos); // posição atual do vídeo

module.exports = function attach(io) {
  const rooms = new Map();
  const newCode = () => { let c; do c = Array.from({ length: 6 }, () => ALPHA[crypto.randomInt(ALPHA.length)]).join(''); while (rooms.has(c)); return c; };
  const snapshot = r => ({ players: [...r.players.values()].map(p => ({ id: p.id, name: p.name, hue: p.hue, st: p.st })), video: r.video, pc: r.pc, lamp: r.lamp, light: r.light });

  function leave(s) {
    const code = s.data.code; if (!code) return;
    s.leave(code); s.data.code = null;
    const r = rooms.get(code); if (!r) return;
    r.players.delete(s.id); io.to(code).emit('p:leave', s.id);
    if (!r.players.size) rooms.delete(code); // último jogador saiu: sala encerrada
  }
  function enter(s, r, name, cb) {
    leave(s);
    const p = { id: s.id, name: clean(name), hue: (r.hues++ * 137) % 360, st: [0, 0, 0, 0, 0], dirty: false };
    r.players.set(s.id, p); s.join(r.code); s.data.code = r.code;
    s.to(r.code).emit('p:join', { id: p.id, name: p.name, hue: p.hue, st: p.st });
    cb({ ok: true, code: r.code, id: s.id, name: p.name, now: Date.now(), ...snapshot(r) });
  }

  io.on('connection', s => {
    const R = () => rooms.get(s.data.code);
    s.on('t', cb => typeof cb === 'function' && cb(Date.now())); // sincronia de relógio cliente↔servidor
    s.on('room:create', (name, cb) => {
      if (typeof cb !== 'function') return;
      const r = { code: newCode(), players: new Map(), video: null, pc: false, lamp: true, light: true, hues: 0 };
      rooms.set(r.code, r); enter(s, r, name, cb);
    });
    s.on('room:join', (code, name, cb) => {
      if (typeof cb !== 'function') return;
      const r = rooms.get(String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, ''));
      if (!r) return cb({ ok: false, error: 'Sala não encontrada. Confira o código e tente de novo.' });
      enter(s, r, name, cb);
    });
    s.on('room:leave', () => leave(s));
    s.on('disconnect', () => leave(s));

    // estado do jogador: [x, z, yaw, pitch, flags(bit0 = usando o computador)]
    s.on('st', a => {
      const p = R()?.players.get(s.id); if (!p || !Array.isArray(a)) return;
      p.st = [num(a[0], 50), num(a[1], 50), num(a[2], 20), num(a[3], 3), a[4] | 0]; p.dirty = true;
    });

    // vídeo compartilhado: {id, playing, pos, at(ms do servidor)}
    const video = (ev, fn) => s.on(ev, v => {
      const r = R(); if (!r || fn(r, v) === false) return;
      io.to(r.code).emit('v', { ...r.video, by: r.players.get(s.id)?.name });
    });
    video('v:load', (r, id) => { if (typeof id !== 'string' || !/^[\w-]{11}$/.test(id)) return false; r.pc = true; r.video = { id, playing: true, pos: 0, at: Date.now() }; });
    video('v:play', r => { if (!r.video) return false; r.video = { ...r.video, pos: cur(r.video), playing: true, at: Date.now() }; });
    video('v:pause', r => { if (!r.video) return false; r.video = { ...r.video, pos: cur(r.video), playing: false, at: Date.now() }; });
    video('v:seek', (r, t) => { if (!r.video || !Number.isFinite(t)) return false; r.video = { ...r.video, pos: Math.max(0, t), at: Date.now() }; });

    s.on('pc', on => { // liga/desliga o computador (desligar pausa o vídeo)
      const r = R(); if (!r) return; r.pc = !!on;
      if (!r.pc && r.video?.playing) r.video = { ...r.video, pos: cur(r.video), playing: false, at: Date.now() };
      io.to(r.code).emit('pc', { pc: r.pc, video: r.video });
    });
    s.on('tg', k => { // interruptores: 'lamp' (luminária) e 'light' (luz do teto)
      const r = R(); if (!r || (k !== 'lamp' && k !== 'light')) return;
      r[k] = !r[k]; io.to(r.code).emit('tg', { lamp: r.lamp, light: r.light });
    });
  });

  // difusão das posições a 20 Hz (só quando há 2+ jogadores e algo mudou)
  setInterval(() => {
    for (const r of rooms.values()) {
      const d = {}; let n = 0;
      for (const p of r.players.values()) if (p.dirty) { d[p.id] = p.st; p.dirty = false; n++; }
      if (n && r.players.size > 1) io.to(r.code).volatile.emit('snap', d);
    }
  }, 50).unref();
  return { rooms };
};
